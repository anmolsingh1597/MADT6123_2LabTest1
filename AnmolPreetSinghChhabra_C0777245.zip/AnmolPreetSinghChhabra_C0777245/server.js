
// let http = require('http');
// let fs = require('fs');

// let handleRequest = (request, response) => {
//     response.writeHead(200, {
//         'Content-Type': 'text/html'
//     });
//     fs.readFile('./index.html', null, function (error, data) {
//         if (error) {
//             response.writeHead(404);
//             respone.write('Whoops! File not found!');
//         } else {
//             response.write(data);
//         }
//         response.end();
//     });
// };

// http.createServer(handleRequest).listen(8000);


// var express = require('express')
// var app = express()
// const sqlite3 = require('sqlite3').verbose();

// // const path = require('path')
// // const dbPath = path.resolve(__dirname, 'amanpreet-c0782918.db')
// // const db = new sqlite3.Database(dbPath)

// // open the database
// let db = new sqlite3.Database('./db/anmolpreetsinghchhabra-c0777245.db', sqlite3.OPEN_READWRITE, (err) => {
//     if (err) {
//       console.error(err.message);
//     }
//     console.log('Connected to the database.');
//   });

// // let sql = `select VegName, (amt*Veggieprice) as Amount from vegetables, price where vegetables.VegId = price.priceId`;

// app.get('/', function (req, res) {
//   res.send(

//     // db.all(sql, [], (err, rows) => {
//     //   if (err) {
//     //     throw err;
//     //   }
//     //   rows.forEach((row) => {
//     //     console.log(row.name);
//     //   });
//     // }))

//     db.serialize(() => {
//         db.each(`select VegetableName, (AmountInKilogram*VegetablePriceInDollarPerKg) as Amount from Vegetables, VegetablePricePerKg where Vegetables.VegetableID = VegetablePricePerKg.VegetablePriceID;`, (err, row) => {
//           if (err) {
//             console.error(err.message);
//           }
//           console.log('table selected'+row.stringify);
//         });
//       }))


//       db.close((err) => {
//       if (err) {
//       console.error(err.message);
//       }
//       console.log('Close the database connection.');
// });

// })
// app.listen(3000)
// var bodyParser = require('body-parser')
 
// // parse application/x-www-form-urlencoded
// app.use(bodyParser.urlencoded({ extended: false }))
 
// // parse application/json
// app.use(bodyParser.json())
 
// app.use(function (req, res) {
//   res.setHeader('Content-Type', 'text/plain')
//   res.write('you posted:\n')
//   res.end(JSON.stringify(req.body, null, 2))
// })


var http = require('http');
var sqlite3 = require('sqlite3').verbose();

var db = new sqlite3.Database('./db/anmolpreetsinghchhabra-c0777245.db');

http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.write('');

//   db.all("CREATE TABLE employees (first_name varchar(255), last_name varchar(255))", function(err, rows) {
//     rows.forEach(function(row) {
//         res.write(row.first_name, row.last_name);
//     })
// });

//   db.all("INSERT INTO employees (first_name,last_name) VALUES ('Me','you')", function(err, rows) {
//     rows.forEach(function(row) {
//         res.write(row.first_name, row.last_name);
//     })
// });

  db.all("select VegetableName, (AmountInKilogram*VegetablePriceInDollarPerKg) as Amount from Vegetables, VegetablePricePerKg where Vegetables.VegetableID = VegetablePricePerKg.VegetablePriceID;", function(err, rows) {

    if (err) {
        res.write(err.message);
      }else{
    rows.forEach(function(row) {
        res.write("<!DOCTYPE html> <html lang='en'> <head><style> table {font-family: arial, sans-serif; border-collapse: collapse; width: 100%;} td, th {border: 1px solid #dddddd;text-align: left;padding: 8px;}tr:nth-child(even) {background-color: #dddddd;}</style><meta charset='UTF-8'><title>Lab Test 1 Solution</title></head><body><table style='width:100%'> <tr><th>Field Name</th><th>Amount</th></tr><tr><td>"+row.VegetableName+"</td><td>"+"$"+row.Amount+"</td></tr></table></body></html>");
        // row.VegetableName+row.Amount+
        
    })
    res.end('');
    db.close();
  }
});


}).listen(8080);